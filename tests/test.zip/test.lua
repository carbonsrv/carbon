content(doctype()(
	tag"body"(
		tag"h1"("hi")
	)
))
